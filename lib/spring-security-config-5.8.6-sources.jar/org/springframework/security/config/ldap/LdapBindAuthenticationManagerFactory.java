/*
 * Copyright 2002-2022 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.config.ldap;

import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.ldap.authentication.BindAuthenticator;

/**
 * Creates an {@link AuthenticationManager} that can perform LDAP authentication using
 * bind authentication.
 *
 * @author Eleftheria Stein
 * @since 5.7
 */
public class LdapBindAuthenticationManagerFactory extends AbstractLdapAuthenticationManagerFactory<BindAuthenticator> {

	public LdapBindAuthenticationManagerFactory(BaseLdapPathContextSource contextSource) {
		super(contextSource);
	}

	@Override
	protected BindAuthenticator createDefaultLdapAuthenticator() {
		return new BindAuthenticator(getContextSource());
	}

}
